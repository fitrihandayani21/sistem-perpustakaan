<?php
/**
 * koneksi.php
 * File koneksi ke database MySQL menggunakan MySQLi.
 * Ubah $host, $user, $pass, $dbname sesuai konfigurasi server kamu.
 */

// -------- KONFIGURASI DATABASE --------
$host   = "localhost:3307";   // alamat server database
$user   = "root";        // username database (default XAMPP: root)
$pass   = "";             // password database (default XAMPP: kosong)
$dbname = "db_kampus";   // nama database

// -------- MEMBUAT KONEKSI --------
$koneksi = mysqli_connect($host, $user, $pass, $dbname, 3307);

// -------- CEK KONEKSI --------
if (!$koneksi) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

// -------- SET KARAKTER SET (agar teks/emoji/karakter khusus aman) --------
mysqli_set_charset($koneksi, "utf8mb4");
?>