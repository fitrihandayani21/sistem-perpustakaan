-- =========================================================
-- DATABASE KAMPUS - SEDERHANA & LENGKAP
-- Import file ini lewat phpMyAdmin atau: mysql -u root -p < db_kampus.sql
-- =========================================================

CREATE DATABASE IF NOT EXISTS db_kampus;
USE db_kampus;

-- -------------------------
-- Tabel Jurusan
-- -------------------------
CREATE TABLE jurusan (
    id_jurusan INT(11) NOT NULL AUTO_INCREMENT,
    kode_jurusan VARCHAR(10) NOT NULL,
    nama_jurusan VARCHAR(100) NOT NULL,
    PRIMARY KEY (id_jurusan)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO jurusan (kode_jurusan, nama_jurusan) VALUES
('TI', 'Teknik Informatika'),
('SI', 'Sistem Informasi'),
('MI', 'Manajemen Informatika'),
('TK', 'Teknik Komputer');

-- -------------------------
-- Tabel Dosen
-- -------------------------
CREATE TABLE dosen (
    id_dosen INT(11) NOT NULL AUTO_INCREMENT,
    nip VARCHAR(20) NOT NULL,
    nama_dosen VARCHAR(100) NOT NULL,
    id_jurusan INT(11) NOT NULL,
    no_hp VARCHAR(20) DEFAULT NULL,
    PRIMARY KEY (id_dosen),
    KEY fk_dosen_jurusan (id_jurusan),
    CONSTRAINT fk_dosen_jurusan FOREIGN KEY (id_jurusan) REFERENCES jurusan (id_jurusan) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO dosen (nip, nama_dosen, id_jurusan, no_hp) VALUES
('198001012010011001', 'Andi Setiawan, S.Kom., M.Kom.', 1, '081234567801'),
('198203152011012002', 'Budi Santoso, S.T., M.T.', 2, '081234567802'),
('198507202012011003', 'Citra Dewi, S.Kom., M.Cs.', 3, '081234567803');

-- -------------------------
-- Tabel Mahasiswa
-- -------------------------
CREATE TABLE mahasiswa (
    nim VARCHAR(15) NOT NULL,
    nama VARCHAR(100) NOT NULL,
    jenis_kelamin ENUM('Laki-laki','Perempuan') NOT NULL,
    tempat_lahir VARCHAR(50) DEFAULT NULL,
    tanggal_lahir DATE DEFAULT NULL,
    alamat TEXT,
    id_jurusan INT(11) NOT NULL,
    id_dosen_wali INT(11) DEFAULT NULL,
    tanggal_daftar DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (nim),
    KEY fk_mhs_jurusan (id_jurusan),
    KEY fk_mhs_dosen (id_dosen_wali),
    CONSTRAINT fk_mhs_jurusan FOREIGN KEY (id_jurusan) REFERENCES jurusan (id_jurusan) ON DELETE CASCADE,
    CONSTRAINT fk_mhs_dosen FOREIGN KEY (id_dosen_wali) REFERENCES dosen (id_dosen) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO mahasiswa (nim, nama, jenis_kelamin, tempat_lahir, tanggal_lahir, alamat, id_jurusan, id_dosen_wali) VALUES
('2024010001', 'Muhammad Fajar', 'Laki-laki', 'Pekanbaru', '2005-03-12', 'Jl. Sudirman No.10, Pekanbaru', 1, 1),
('2024010002', 'Siti Aisyah', 'Perempuan', 'Medan', '2005-07-25', 'Jl. Gatot Subroto No.5, Medan', 2, 2),
('2024010003', 'Rian Hidayat', 'Laki-laki', 'Padang', '2004-11-02', 'Jl. Diponegoro No.8, Padang', 3, 3);