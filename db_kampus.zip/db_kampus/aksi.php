<?php
/**
 * aksi.php
 * Menangani semua proses CRUD (Create, Read, Update, Delete)
 * untuk data Mahasiswa, Dosen, dan Jurusan.
 * Semua input dibersihkan lebih dulu lewat anti_injection().
 */

require_once "koneksi.php";
require_once "fungsi_antiinjection.php";
require_once "fungsi_waktu.php";

$aksi = isset($_GET['aksi']) ? $_GET['aksi'] : (isset($_POST['aksi']) ? $_POST['aksi'] : '');

switch ($aksi) {

    // =========================================================
    // ================= MAHASISWA =============================
    // =========================================================

    case 'tambah_mahasiswa':
        $nim            = anti_injection($_POST['nim']);
        $nama           = anti_injection($_POST['nama']);
        $jenis_kelamin  = anti_injection($_POST['jenis_kelamin']);
        $tempat_lahir   = anti_injection($_POST['tempat_lahir']);
        $tanggal_lahir  = anti_injection($_POST['tanggal_lahir']);
        $alamat         = anti_injection($_POST['alamat']);
        $id_jurusan     = anti_injection($_POST['id_jurusan']);
        $id_dosen_wali  = anti_injection($_POST['id_dosen_wali']);
        $waktu          = waktu_sekarang();

        // Cek NIM sudah dipakai atau belum
        $cek = mysqli_query($koneksi, "SELECT nim FROM mahasiswa WHERE nim = '$nim'");
        if (mysqli_num_rows($cek) > 0) {
            header("Location: index.php?halaman=mahasiswa&pesan=nim_duplikat");
            exit;
        }

        $query = "INSERT INTO mahasiswa
                    (nim, nama, jenis_kelamin, tempat_lahir, tanggal_lahir, alamat, id_jurusan, id_dosen_wali, tanggal_daftar)
                  VALUES
                    ('$nim', '$nama', '$jenis_kelamin', '$tempat_lahir', '$tanggal_lahir', '$alamat', '$id_jurusan', '$id_dosen_wali', '$waktu')";

        if (mysqli_query($koneksi, $query)) {
            header("Location: index.php?halaman=mahasiswa&pesan=tambah_sukses");
        } else {
            header("Location: index.php?halaman=mahasiswa&pesan=gagal&error=" . urlencode(mysqli_er]]]\\\\\\\\\\\\\\\\\\\\\\\\\\\ror($koneksi)));
        }
        exit;

    case 'edit_mahasiswa':
        $nim_asli       = anti_injection($_POST['nim_asli']);
        $nama           = anti_injection($_POST['nama']);
        $jenis_kelamin  = anti_injection($_POST['jenis_kelamin']);
        $tempat_lahir   = anti_injection($_POST['tempat_lahir']);
        $tanggal_lahir  = anti_injection($_POST['tanggal_lahir']);
        $alamat         = anti_injection($_POST['alamat']);
        $id_jurusan     = anti_injection($_POST['id_jurusan']);
        $id_dosen_wali  = anti_injection($_POST['id_dosen_wali']);

        $query = "UPDATE mahasiswa SET
                    nama = '$nama',
                    jenis_kelamin = '$jenis_kelamin',
                    tempat_lahir = '$tempat_lahir',
                    tanggal_lahir = '$tanggal_lahir',
                    alamat = '$alamat',
                    id_jurusan = '$id_jurusan',
                    id_dosen_wali = '$id_dosen_wali'
                  WHERE nim = '$nim_asli'";

        if (mysqli_query($koneksi, $query)) {
            header("Location: index.php?halaman=mahasiswa&pesan=edit_sukses");
        } else {
            header("Location: index.php?halaman=mahasiswa&pesan=gagal&error=" . urlencode(mysqli_error($koneksi)));
        }
        exit;

    case 'hapus_mahasiswa':
        $nim = anti_injection($_GET['nim']);
        $query = "DELETE FROM mahasiswa WHERE nim = '$nim'";

        if (mysqli_query($koneksi, $query)) {
            header("Location: index.php?halaman=mahasiswa&pesan=hapus_sukses");
        } else {
            header("Location: index.php?halaman=mahasiswa&pesan=gagal&error=" . urlencode(mysqli_error($koneksi)));
        }
        exit;

    // =========================================================
    // ================= JURUSAN ===============================
    // =========================================================

    case 'tambah_jurusan':
        $kode  = anti_injection($_POST['kode_jurusan']);
        $nama  = anti_injection($_POST['nama_jurusan']);

        $query = "INSERT INTO jurusan (kode_jurusan, nama_jurusan) VALUES ('$kode', '$nama')";

        if (mysqli_query($koneksi, $query)) {
            header("Location: index.php?halaman=jurusan&pesan=tambah_sukses");
        } else {
            header("Location: index.php?halaman=jurusan&pesan=gagal&error=" . urlencode(mysqli_error($koneksi)));
        }
        exit;

    case 'edit_jurusan':
        $id    = anti_injection($_POST['id_jurusan']);
        $kode  = anti_injection($_POST['kode_jurusan']);
        $nama  = anti_injection($_POST['nama_jurusan']);

        $query = "UPDATE jurusan SET kode_jurusan = '$kode', nama_jurusan = '$nama' WHERE id_jurusan = '$id'";

        if (mysqli_query($koneksi, $query)) {
            header("Location: index.php?halaman=jurusan&pesan=edit_sukses");
        } else {
            header("Location: index.php?halaman=jurusan&pesan=gagal&error=" . urlencode(mysqli_error($koneksi)));
        }
        exit;

    case 'hapus_jurusan':
        $id = anti_injection($_GET['id']);
        $query = "DELETE FROM jurusan WHERE id_jurusan = '$id'";

        if (mysqli_query($koneksi, $query)) {
            header("Location: index.php?halaman=jurusan&pesan=hapus_sukses");
        } else {
            header("Location: index.php?halaman=jurusan&pesan=gagal&error=" . urlencode(mysqli_error($koneksi)));
        }
        exit;

    // =========================================================
    // ================= DOSEN =================================
    // =========================================================

    case 'tambah_dosen':
        $nip        = anti_injection($_POST['nip']);
        $nama       = anti_injection($_POST['nama_dosen']);
        $id_jurusan = anti_injection($_POST['id_jurusan']);
        $no_hp      = anti_injection($_POST['no_hp']);

        $query = "INSERT INTO dosen (nip, nama_dosen, id_jurusan, no_hp) VALUES ('$nip', '$nama', '$id_jurusan', '$no_hp')";

        if (mysqli_query($koneksi, $query)) {
            header("Location: index.php?halaman=dosen&pesan=tambah_sukses");
        } else {
            header("Location: index.php?halaman=dosen&pesan=gagal&error=" . urlencode(mysqli_error($koneksi)));
        }
        exit;

    case 'edit_dosen':
        $id         = anti_injection($_POST['id_dosen']);
        $nip        = anti_injection($_POST['nip']);
        $nama       = anti_injection($_POST['nama_dosen']);
        $id_jurusan = anti_injection($_POST['id_jurusan']);
        $no_hp      = anti_injection($_POST['no_hp']);

        $query = "UPDATE dosen SET nip = '$nip', nama_dosen = '$nama', id_jurusan = '$id_jurusan', no_hp = '$no_hp' WHERE id_dosen = '$id'";

        if (mysqli_query($koneksi, $query)) {
            header("Location: index.php?halaman=dosen&pesan=edit_sukses");
        } else {
            header("Location: index.php?halaman=dosen&pesan=gagal&error=" . urlencode(mysqli_error($koneksi)));
        }
        exit;

    case 'hapus_dosen':
        $id = anti_injection($_GET['id']);
        $query = "DELETE FROM dosen WHERE id_dosen = '$id'";

        if (mysqli_query($koneksi, $query)) {
            header("Location: index.php?halaman=dosen&pesan=hapus_sukses");
        } else {
            header("Location: index.php?halaman=dosen&pesan=gagal&error=" . urlencode(mysqli_error($koneksi)));
        }
        exit;

    // =========================================================
    // ================= PENCARIAN ==============================
    // =========================================================

    case 'cari_mahasiswa':
        // Diproses langsung di index.php lewat parameter GET 'kata_kunci'
        $kata_kunci = anti_injection($_GET['kata_kunci']);
        header("Location: index.php?halaman=mahasiswa&kata_kunci=" . urlencode($kata_kunci));
        exit;

    default:
        header("Location: index.php");
        exit;
}
?>