<?php
/**
 * fungsi_waktu.php
 * Kumpulan fungsi untuk memformat tanggal & waktu ke format Indonesia.
 */

/**
 * Mengubah format tanggal dari YYYY-MM-DD menjadi "12 Maret 2005"
 *
 * @param string $tanggal  Format: YYYY-MM-DD
 * @return string
 */
function format_tanggal_indonesia($tanggal)
{
    if (empty($tanggal) || $tanggal == "0000-00-00") {
        return "-";
    }

    $bulan = [
        1 => "Januari", 2 => "Februari", 3 => "Maret", 4 => "April",
        5 => "Mei", 6 => "Juni", 7 => "Juli", 8 => "Agustus",
        9 => "September", 10 => "Oktober", 11 => "November", 12 => "Desember"
    ];

    $pecah = explode("-", $tanggal);
    if (count($pecah) < 3) return $tanggal;

    $tahun = $pecah[0];
    $bulan_angka = (int) $pecah[1];
    $hari = (int) $pecah[2];

    return $hari . " " . $bulan[$bulan_angka] . " " . $tahun;
}

/**
 * Mengubah format datetime (YYYY-MM-DD HH:MM:SS) menjadi
 * "12 Maret 2005, 14:30 WIB"
 *
 * @param string $datetime
 * @return string
 */
function format_datetime_indonesia($datetime)
{
    if (empty($datetime) || $datetime == "0000-00-00 00:00:00") {
        return "-";
    }

    $pecah = explode(" ", $datetime);
    $tanggal = format_tanggal_indonesia($pecah[0]);
    $jam = isset($pecah[1]) ? substr($pecah[1], 0, 5) : "00:00";

    return $tanggal . ", " . $jam . " WIB";
}

/**
 * Menghitung umur berdasarkan tanggal lahir.
 *
 * @param string $tanggal_lahir  Format: YYYY-MM-DD
 * @return int   Umur dalam tahun
 */
function hitung_umur($tanggal_lahir)
{
    if (empty($tanggal_lahir) || $tanggal_lahir == "0000-00-00") {
        return 0;
    }

    $lahir = new DateTime($tanggal_lahir);
    $sekarang = new DateTime('today');
    $selisih = $lahir->diff($sekarang);

    return (int) $selisih->y;
}

/**
 * Mengambil waktu sekarang dalam format YYYY-MM-DD HH:MM:SS
 * (berguna untuk menyimpan timestamp saat insert data)
 *
 * @return string
 */
function waktu_sekarang()
{
    date_default_timezone_set('Asia/Jakarta');
    return date('Y-m-d H:i:s');
}
?>