<?php
/**
 * fungsi_antiinjection.php
 * Kumpulan fungsi untuk membersihkan input dari user
 * agar terhindar dari SQL Injection & XSS sederhana.
 *
 * Wajib di-include SETELAH koneksi.php karena fungsi anti_injection()
 * menggunakan mysqli_real_escape_string() yang butuh koneksi aktif.
 */

require_once "koneksi.php";

/**
 * Membersihkan input dari SQL Injection & tag HTML/script berbahaya.
 *
 * @param string $data   Data mentah dari form/GET/POST
 * @return string        Data yang sudah bersih dan aman
 */
function anti_injection($data)
{
    global $koneksi;

    // 1. Hilangkan spasi di awal & akhir
    $data = trim($data);

    // 2. Hilangkan backslash
    $data = stripslashes($data);

    // 3. Ubah karakter spesial HTML jadi entity (cegah XSS)
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');

    // 4. Escape karakter berbahaya untuk query SQL (cegah SQL Injection)
    $data = mysqli_real_escape_string($koneksi, $data);

    return $data;
}

/**
 * Membersihkan seluruh array input (misalnya $_POST atau $_GET) sekaligus.
 *
 * @param array $array
 * @return array
 */
function anti_injection_array($array)
{
    $hasil = [];
    foreach ($array as $key => $value) {
        $hasil[$key] = anti_injection($value);
    }
    return $hasil;
}

/**
 * Validasi apakah input hanya berisi angka (misal untuk id/nim).
 *
 * @param string $data
 * @return bool
 */
function hanya_angka($data)
{
    return preg_match('/^[0-9]+$/', $data) === 1;
}
?>