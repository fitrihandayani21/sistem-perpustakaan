<?php
require_once "koneksi.php";
require_once "fungsi_antiinjection.php";
require_once "fungsi_waktu.php";

$halaman = isset($_GET['halaman']) ? $_GET['halaman'] : 'mahasiswa';
$pesan   = isset($_GET['pesan']) ? $_GET['pesan'] : '';

// Ambil data jurusan & dosen untuk dropdown (dipakai di beberapa halaman)
$list_jurusan = mysqli_query($koneksi, "SELECT * FROM jurusan ORDER BY nama_jurusan ASC");
$list_dosen   = mysqli_query($koneksi, "SELECT * FROM dosen ORDER BY nama_dosen ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Sistem Informasi Kampus</title>
<style>
    * { box-sizing: border-box; }
    body {
        font-family: 'Segoe UI', Arial, sans-serif;
        background: #f2f4f7;
        margin: 0;
        color: #222;
    }
    header {
        background: #1e3a5f;
        color: #fff;
        padding: 18px 30px;
    }
    header h1 { margin: 0; font-size: 22px; }
    header p { margin: 4px 0 0; font-size: 13px; color: #cfd9e6; }
    nav {
        background: #274b73;
        padding: 0 30px;
    }
    nav a {
        display: inline-block;
        color: #fff;
        text-decoration: none;
        padding: 12px 18px;
        font-size: 14px;
    }
    nav a.aktif, nav a:hover { background: #1e3a5f; }
    .container { max-width: 1100px; margin: 25px auto; padding: 0 20px; }
    .card {
        background: #fff;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }
    .card h2 { margin-top: 0; font-size: 18px; color: #1e3a5f; border-bottom: 2px solid #eee; padding-bottom: 10px; }
    table { width: 100%; border-collapse: collapse; font-size: 14px; }
    th, td { padding: 10px; text-align: left; border-bottom: 1px solid #eee; }
    th { background: #f7f9fc; color: #1e3a5f; }
    tr:hover { background: #fafcff; }
    .btn {
        display: inline-block;
        padding: 6px 12px;
        border-radius: 5px;
        text-decoration: none;
        font-size: 13px;
        border: none;
        cursor: pointer;
    }
    .btn-tambah { background: #2b7a3f; color: #fff; margin-bottom: 15px; }
    .btn-edit { background: #f0ad4e; color: #fff; }
    .btn-hapus { background: #d9534f; color: #fff; }
    .btn-simpan { background: #1e3a5f; color: #fff; padding: 9px 20px; }
    .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
    .form-grid label { font-size: 13px; font-weight: 600; color: #444; display: block; margin-bottom: 4px; }
    .form-grid input, .form-grid select, .form-grid textarea {
        width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 5px; font-size: 14px;
    }
    .full { grid-column: 1 / -1; }
    .alert { padding: 12px 16px; border-radius: 6px; margin-bottom: 15px; font-size: 14px; }
    .alert-sukses { background: #dff5e1; color: #1e6b34; border: 1px solid #b7e4c2; }
    .alert-gagal { background: #fde2e1; color: #a12b26; border: 1px solid #f5b8b5; }
    .search-box { margin-bottom: 15px; }
    .search-box input { padding: 8px; width: 250px; border: 1px solid #ccc; border-radius: 5px; }
    .search-box button { padding: 8px 14px; border-radius: 5px; border: none; background: #1e3a5f; color: #fff; cursor: pointer; }
    .badge { padding: 2px 8px; border-radius: 10px; font-size: 12px; background: #e6edf5; color: #1e3a5f; }
    .aksi-cell { white-space: nowrap; }
    .aksi-cell a, .aksi-cell button { margin-right: 5px; }
</style>
</head>
<body>

<header>
    <h1>🎓 Sistem Informasi Kampus</h1>
    <p>Data Mahasiswa, Dosen, dan prodi</p>
</header>

<nav>
    <a href="index.php?halaman=mahasiswa" class="<?= $halaman=='mahasiswa'?'aktif':'' ?>">Mahasiswa</a>
    <a href="index.php?halaman=dosen" class="<?= $halaman=='dosen'?'aktif':'' ?>">Dosen</a>
    <a href="index.php?halaman=jurusan" class="<?= $halaman=='jurusan'?'aktif':'' ?>">prodi</a>
</nav>

<div class="container">

<?php
// =========================================================
// NOTIFIKASI PESAN
// =========================================================
if ($pesan) {
    $teks = "";
    $jenis = "sukses";
    switch ($pesan) {
        case 'tambah_sukses': $teks = "Data berhasil ditambahkan."; break;
        case 'edit_sukses':   $teks = "Data berhasil diperbarui."; break;
        case 'hapus_sukses':  $teks = "Data berhasil dihapus."; break;
        case 'nim_duplikat':  $teks = "NIM tersebut sudah terdaftar."; $jenis = "gagal"; break;
        case 'gagal':
            $teks = "Terjadi kesalahan: " . htmlspecialchars($_GET['error'] ?? 'tidak diketahui');
            $jenis = "gagal";
            break;
    }
    if ($teks) {
        echo '<div class="alert alert-' . $jenis . '">' . $teks . '</div>';
    }
}

// =========================================================
// HALAMAN MAHASISWA
// =========================================================
if ($halaman == 'mahasiswa'):

    // Jika mode edit, ambil data mahasiswa yang dipilih
    $data_edit = null;
    if (isset($_GET['edit'])) {
        $nim_edit = anti_injection($_GET['edit']);
        $q = mysqli_query($koneksi, "SELECT * FROM mahasiswa WHERE nim = '$nim_edit'");
        $data_edit = mysqli_fetch_assoc($q);
    }

    // Pencarian
    $kata_kunci = isset($_GET['kata_kunci']) ? anti_injection($_GET['kata_kunci']) : '';
    $where = '';
    if ($kata_kunci != '') {
        $where = "WHERE m.nama LIKE '%$kata_kunci%' OR m.nim LIKE '%$kata_kunci%'";
    }
?>
    <div class="card">
        <h2><?= $data_edit ? 'Ubah Data Mahasiswa' : 'Tambah Data Mahasiswa' ?></h2>
        <form action="aksi.php" method="POST">
            <input type="hidden" name="aksi" value="<?= $data_edit ? 'edit_mahasiswa' : 'tambah_mahasiswa' ?>">
            <?php if ($data_edit): ?>
                <input type="hidden" name="nim_asli" value="<?= htmlspecialchars($data_edit['nim']) ?>">
            <?php endif; ?>

            <div class="form-grid">
                <div>
                    <label>NIM</label>
                    <input type="text" name="nim" required
                        value="<?= $data_edit ? htmlspecialchars($data_edit['nim']) : '' ?>"
                        <?= $data_edit ? 'readonly' : '' ?>>
                </div>
                <div>
                    <label>Nama Lengkap</label>
                    <input type="text" name="nama" required value="<?= $data_edit ? htmlspecialchars($data_edit['nama']) : '' ?>">
                </div>
                <div>
                    <label>Jenis Kelamin</label>
                    <select name="jenis_kelamin" required>
                        <option value="Laki-laki" <?= ($data_edit && $data_edit['jenis_kelamin']=='Laki-laki') ? 'selected':'' ?>>Laki-laki</option>
                        <option value="Perempuan" <?= ($data_edit && $data_edit['jenis_kelamin']=='Perempuan') ? 'selected':'' ?>>Perempuan</option>
                    </select>
                </div>
                <div>
                    <label>Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" value="<?= $data_edit ? htmlspecialchars($data_edit['tempat_lahir']) : '' ?>">
                </div>
                <div>
                    <label>Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" value="<?= $data_edit ? htmlspecialchars($data_edit['tanggal_lahir']) : '' ?>">
                </div>
                <div>
                    <label>prodi</label>
                    <select name="id_jurusan" required>
                        <?php mysqli_data_seek($list_jurusan, 0); while ($j = mysqli_fetch_assoc($list_jurusan)): ?>
                            <option value="<?= $j['id_jurusan'] ?>" <?= ($data_edit && $data_edit['id_jurusan']==$j['id_jurusan'])?'selected':'' ?>>
                                <?= htmlspecialchars($j['nama_jurusan']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div>
                    <label>Dosen pembingbing akademik</label>
                    <select name="id_dosen_wali">
                        <option value="">- Belum ada -</option>
                        <?php mysqli_data_seek($list_dosen, 0); while ($d = mysqli_fetch_assoc($list_dosen)): ?>
                            <option value="<?= $d['id_dosen'] ?>" <?= ($data_edit && $data_edit['id_dosen_wali']==$d['id_dosen'])?'selected':'' ?>>
                                <?= htmlspecialchars($d['nama_dosen']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="full">
                    <label>Alamat</label>
                    <textarea name="alamat" rows="2"><?= $data_edit ? htmlspecialchars($data_edit['alamat']) : '' ?></textarea>
                </div>
            </div>
            <br>
            <button type="submit" class="btn btn-simpan"><?= $data_edit ? 'Simpan Perubahan' : 'Tambah Mahasiswa' ?></button>
            <?php if ($data_edit): ?>
                <a href="index.php?halaman=mahasiswa" class="btn" style="background:#999;color:#fff;">Batal</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="card">
        <h2>Daftar Mahasiswa</h2>

        <form class="search-box" action="index.php" method="GET">
            <input type="hidden" name="halaman" value="mahasiswa">
            <input type="text" name="kata_kunci" placeholder="Cari NIM atau nama..." value="<?= htmlspecialchars($kata_kunci) ?>">
            <button type="submit">Cari</button>
        </form>

        <table>
            <tr>
                <th>NIM</th>
                <th>Nama</th>
                <th>L/P</th>
                <th>Tempat, Tgl Lahir</th>
                <th>Jurusan</th>
                <th>Dosen Wali</th>
                <th>Terdaftar</th>
                <th>Aksi</th>
            </tr>
            <?php
            $query = "SELECT m.*, j.nama_jurusan, d.nama_dosen
                      FROM mahasiswa m
                      LEFT JOIN jurusan j ON m.id_jurusan = j.id_jurusan
                      LEFT JOIN dosen d ON m.id_dosen_wali = d.id_dosen
                      $where
                      ORDER BY m.nama ASC";
            $hasil = mysqli_query($koneksi, $query);

            if (mysqli_num_rows($hasil) == 0): ?>
                <tr><td colspan="8" style="text-align:center;color:#888;">Belum ada data mahasiswa.</td></tr>
            <?php else:
                while ($row = mysqli_fetch_assoc($hasil)): ?>
                <tr>
                    <td><?= htmlspecialchars($row['nim']) ?></td>
                    <td><?= htmlspecialchars($row['nama']) ?></td>
                    <td><?= htmlspecialchars($row['jenis_kelamin']) ?></td>
                    <td><?= htmlspecialchars($row['tempat_lahir']) ?>, <?= format_tanggal_indonesia($row['tanggal_lahir']) ?>
                        <br><span class="badge"><?= hitung_umur($row['tanggal_lahir']) ?> tahun</span>
                    </td>
                    <td><?= htmlspecialchars($row['nama_jurusan'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($row['nama_dosen'] ?? '-') ?></td>
                    <td><?= format_datetime_indonesia($row['tanggal_daftar']) ?></td>
                    <td class="aksi-cell">
                        <a class="btn btn-edit" href="index.php?halaman=mahasiswa&edit=<?= urlencode($row['nim']) ?>">Ubah</a>
                        <a class="btn btn-hapus" href="aksi.php?aksi=hapus_mahasiswa&nim=<?= urlencode($row['nim']) ?>"
                           onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</a>
                    </td>
                </tr>
            <?php endwhile; endif; ?>
        </table>
    </div>

<?php
// =========================================================
// HALAMAN DOSEN
// =========================================================
elseif ($halaman == 'dosen'):

    $data_edit = null;
    if (isset($_GET['edit'])) {
        $id_edit = anti_injection($_GET['edit']);
        $q = mysqli_query($koneksi, "SELECT * FROM dosen WHERE id_dosen = '$id_edit'");
        $data_edit = mysqli_fetch_assoc($q);
    }
?>
    <div class="card">
        <h2><?= $data_edit ? 'Ubah Data Dosen' : 'Tambah Data Dosen' ?></h2>
        <form action="aksi.php" method="POST">
            <input type="hidden" name="aksi" value="<?= $data_edit ? 'edit_dosen' : 'tambah_dosen' ?>">
            <?php if ($data_edit): ?>
                <input type="hidden" name="id_dosen" value="<?= $data_edit['id_dosen'] ?>">
            <?php endif; ?>
            <div class="form-grid">
                <div>
                    <label>NIDNa</label>
                    <input type="text" name="nip" required value="<?= $data_edit ? htmlspecialchars($data_edit['nip']) : '' ?>">
                </div>
                <div>
                    <label>Nama Dosen</label>
                    <input type="text" name="nama_dosen" required value="<?= $data_edit ? htmlspecialchars($data_edit['nama_dosen']) : '' ?>">
                </div>
                <div>
                    <label>prodi</label>
                    <select name="id_jurusan" required>
                        <?php mysqli_data_seek($list_jurusan, 0); while ($j = mysqli_fetch_assoc($list_jurusan)): ?>
                            <option value="<?= $j['id_jurusan'] ?>" <?= ($data_edit && $data_edit['id_jurusan']==$j['id_jurusan'])?'selected':'' ?>>
                                <?= htmlspecialchars($j['nama_jurusan']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div>
                    <label>No. HP</label>
                    <input type="text" name="no_hp" value="<?= $data_edit ? htmlspecialchars($data_edit['no_hp']) : '' ?>">
                </div>
            </div>
            <br>
            <button type="submit" class="btn btn-simpan"><?= $data_edit ? 'Simpan Perubahan' : 'Tambah Dosen' ?></button>
            <?php if ($data_edit): ?>
                <a href="index.php?halaman=dosen" class="btn" style="background:#999;color:#fff;">Batal</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="card">
        <h2>Daftar Dosen</h2>
        <table>
            <tr>
                <th>NIP</th>
                <th>Nama Dosen</th>
                <th>Jurusan</th>
                <th>No. HP</th>
                <th>Aksi</th>
            </tr>
            <?php
            $query = "SELECT d.*, j.nama_jurusan FROM dosen d
                      LEFT JOIN jurusan j ON d.id_jurusan = j.id_jurusan
                      ORDER BY d.nama_dosen ASC";
            $hasil = mysqli_query($koneksi, $query);
            if (mysqli_num_rows($hasil) == 0): ?>
                <tr><td colspan="5" style="text-align:center;color:#888;">Belum ada data dosen.</td></tr>
            <?php else:
                while ($row = mysqli_fetch_assoc($hasil)): ?>
                <tr>
                    <td><?= htmlspecialchars($row['nip']) ?></td>
                    <td><?= htmlspecialchars($row['nama_dosen']) ?></td>
                    <td><?= htmlspecialchars($row['nama_jurusan'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($row['no_hp'] ?? '-') ?></td>
                    <td class="aksi-cell">
                        <a class="btn btn-edit" href="index.php?halaman=dosen&edit=<?= $row['id_dosen'] ?>">Ubah</a>
                        <a class="btn btn-hapus" href="aksi.php?aksi=hapus_dosen&id=<?= $row['id_dosen'] ?>"
                           onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</a>
                    </td>
                </tr>
            <?php endwhile; endif; ?>
        </table>
    </div>

<?php
// =========================================================
// HALAMAN JURUSAN
// =========================================================
elseif ($halaman == 'jurusan'):

    $data_edit = null;
    if (isset($_GET['edit'])) {
        $id_edit = anti_injection($_GET['edit']);
        $q = mysqli_query($koneksi, "SELECT * FROM jurusan WHERE id_jurusan = '$id_edit'");
        $data_edit = mysqli_fetch_assoc($q);
    }
?>
    <div class="card">
        <h2><?= $data_edit ? 'Ubah Data Jurusan' : 'Tambah Data Jurusan' ?></h2>
        <form action="aksi.php" method="POST">
            <input type="hidden" name="aksi" value="<?= $data_edit ? 'edit_jurusan' : 'tambah_jurusan' ?>">
            <?php if ($data_edit): ?>
                <input type="hidden" name="id_jurusan" value="<?= $data_edit['id_jurusan'] ?>">
            <?php endif; ?>
            <div class="form-grid">
                <div>
                    <label>Kode prodi</label>
                    <input type="text" name="kode_jurusan" required value="<?= $data_edit ? htmlspecialchars($data_edit['kode_jurusan']) : '' ?>">
                </div>
                <div>
                    <label>Nama prodi</label>
                    <input type="text" name="nama_jurusan" required value="<?= $data_edit ? htmlspecialchars($data_edit['nama_jurusan']) : '' ?>">
                </div>
            </div>
            <br>
            <button type="submit" class="btn btn-simpan"><?= $data_edit ? 'Simpan Perubahan' : 'Tambah prodi' ?></button>
            <?php if ($data_edit): ?>
                <a href="index.php?halaman=jurusan" class="btn" style="background:#999;color:#fff;">Batal</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="card">
        <h2>Daftar Jurusan</h2>
        <table>
            <tr>
                <th>Kode</th>
                <th>Nama Jurusan</th>
                <th>Jumlah Mahasiswa</th>
                <th>Aksi</th>
            </tr>
            <?php
            mysqli_data_seek($list_jurusan, 0);
            while ($row = mysqli_fetch_assoc($list_jurusan)):
                $jml = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM mahasiswa WHERE id_jurusan = " . $row['id_jurusan']));
            ?>
                <tr>
                    <td><?= htmlspecialchars($row['kode_jurusan']) ?></td>
                    <td><?= htmlspecialchars($row['nama_jurusan']) ?></td>
                    <td><span class="badge"><?= $jml['total'] ?> mahasiswa</span></td>
                    <td class="aksi-cell">
                        <a class="btn btn-edit" href="index.php?halaman=jurusan&edit=<?= $row['id_jurusan'] ?>">Ubah</a>
                        <a class="btn btn-hapus" href="aksi.php?aksi=hapus_jurusan&id=<?= $row['id_jurusan'] ?>"
                           onclick="return confirm('Yakin ingin menghapus data ini? Semua data dosen & mahasiswa terkait juga akan terhapus.');">Hapus</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>

<?php endif; ?>

</div>

<div style="text-align:center;color:#999;font-size:12px;padding:20px;">
    Sistem Informasi Kampus &copy; <?= date('Y') ?>
</div>

</body>
</html>